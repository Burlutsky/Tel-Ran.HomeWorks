import {Container, Typography} from '@mui/material';

export default function Orders() {
    return (
        <Container sx={{py: 3}}>
            <Typography variant="h4" gutterBottom>src/pages/Orders.tsx</Typography>
            <Typography>Public access</Typography>
        </Container>
    );
}
