import SignIn from "@/templates/SignIn.tsx";

export default function Login() {

    return (
        <SignIn/>
    );
}
