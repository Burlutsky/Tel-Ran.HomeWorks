Implements html page using css by template Example.png

It is necessary to draw the page without using tables, only float and positions. The blue part of the page should occupy 100% of the visible part of the screen

