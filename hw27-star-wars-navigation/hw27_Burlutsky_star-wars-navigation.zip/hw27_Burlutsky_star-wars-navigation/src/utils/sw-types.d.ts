
export type HeroInfo = {
    name: string,
    img: string
}