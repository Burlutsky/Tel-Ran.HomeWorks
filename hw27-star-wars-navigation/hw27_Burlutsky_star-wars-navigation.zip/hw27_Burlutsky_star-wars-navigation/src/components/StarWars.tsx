

const StarWars = () => {
    return (
        <div>
StarWars
        </div>
    );
};

export default StarWars;