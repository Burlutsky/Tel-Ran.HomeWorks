

const AboutMe = () => {
    return (
        <div>
            About
        </div>
    );
};

export default AboutMe;