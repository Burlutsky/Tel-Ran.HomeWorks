export type NavItem = {
    title: string;
    page: string;
}