import UserStats from "./UserStats.tsx";


const SideBar = () => {
    return (
        <div className={'sidebar'}><UserStats/></div>
    )
};

export default SideBar;