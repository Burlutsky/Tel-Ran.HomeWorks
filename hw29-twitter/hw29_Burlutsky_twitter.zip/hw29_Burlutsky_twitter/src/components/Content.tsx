const Content = () => {
    return (
        <div className={'content'}>
            New content will be here soon!
        </div>
    );
};

export default Content;