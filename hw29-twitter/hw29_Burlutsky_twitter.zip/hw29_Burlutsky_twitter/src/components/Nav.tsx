import UserAvatar from "./UserAvatar.tsx";


const Nav = () => {
    return (
        <div className={'nav'}><UserAvatar/></div>
    );
};

export default Nav;