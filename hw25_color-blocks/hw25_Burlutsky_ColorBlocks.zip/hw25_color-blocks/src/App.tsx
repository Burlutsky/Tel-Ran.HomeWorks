import './App.css'
import {ColorGrid} from "./components/ColorGrid.tsx";

function App() {

  return (
    <>
        <ColorGrid />
    </>
  )
}

export default App
