export enum Paths {
    HOME = '/',
    ORDERS = 'orders',
    PRODUCTS = 'products',
    CUSTOMERS = 'customers',
    CART = 'cart',
    BREAD = 'bread',
    DAIRY = 'dairy',
    ERROR = 'error',
    LOGIN = 'login',
    LOGOUT = 'logout',
    REGISTRATION='registration'
}