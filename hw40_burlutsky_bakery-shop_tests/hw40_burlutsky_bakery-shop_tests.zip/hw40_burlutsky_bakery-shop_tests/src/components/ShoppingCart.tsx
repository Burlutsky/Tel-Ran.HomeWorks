

const ShoppingCart = () => {
    return (
        <div>
            Shopping Cart
        </div>
    );
};

export default ShoppingCart;