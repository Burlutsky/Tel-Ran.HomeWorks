

const Dairy = () => {
    return (
        <div>
            Dairy
        </div>
    );
};

export default Dairy;