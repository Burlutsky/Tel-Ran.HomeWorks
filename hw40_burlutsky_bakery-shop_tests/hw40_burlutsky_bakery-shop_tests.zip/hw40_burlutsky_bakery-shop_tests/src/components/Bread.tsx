

const Bread = () => {
    return (
        <div>
            Bread
        </div>
    );
};

export default Bread;