import * as React from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import FormLabel from '@mui/material/FormLabel';
import FormControl from '@mui/material/FormControl';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import {SitemarkIcon} from './CustomIcons';
import {Card, SignInContainer} from "./SignIn.tsx";
import {Link} from "react-router-dom";
import type {SignUpData} from "../../utils/app-types.ts";
import {validateCredentials} from "../../utils/validateCredentials.ts";
import {parseFullName} from "../../utils/tools.ts";

export default function SignUp(props: { func: (data: SignUpData) => void }) {
    const [emailError, setEmailError] = React.useState(false);
    const [emailErrorMessage, setEmailErrorMessage] = React.useState('');
    const [passwordError, setPasswordError] = React.useState(false);
    const [passwordErrorMessage, setPasswordErrorMessage] = React.useState('');
    const [nameError, setNameError] = React.useState(false);
    const [nameErrorMessage, setNameErrorMessage] = React.useState('');


    const validateInputs = () => {
        const email = document.getElementById('email') as HTMLInputElement;
        const password = document.getElementById('password') as HTMLInputElement;
        const name = document.getElementById('name') as HTMLInputElement;

        return validateCredentials(
            {email, password, name},
            {
                setEmailError, setEmailErrorMessage,
                setPasswordError, setPasswordErrorMessage,
                setNameError, setNameErrorMessage
            }
        );
    };

    const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        if (nameError || emailError || passwordError) {
            return;
        }
        const data = new FormData(event.currentTarget);
        const fullName = parseFullName(data.get('name') as string);
        props.func({
            name: fullName.name,
            lastName: fullName.lastName,
            email: data.get('email') as string,
            password: data.get('password') as string,
        });
    };

    return (
        <Box>

            <SignInContainer direction="column" justifyContent="space-between">
                <Card variant="outlined">
                    <SitemarkIcon/>
                    <Typography
                        component="h1"
                        variant="h4"
                        sx={{width: '100%', fontSize: 'clamp(2rem, 10vw, 2.15rem)'}}
                    >
                        Sign up
                    </Typography>
                    <Box
                        component="form"
                        onSubmit={handleSubmit}
                        sx={{display: 'flex', flexDirection: 'column', gap: 2}}
                    >
                        <FormControl>
                            <FormLabel htmlFor="name">Full name</FormLabel>
                            <TextField
                                autoComplete="name"
                                name="name"
                                required
                                fullWidth
                                id="name"
                                placeholder="John Snow"
                                error={nameError}
                                helperText={nameErrorMessage}
                                color={nameError ? 'error' : 'primary'}
                            />
                        </FormControl>
                        <FormControl>
                            <FormLabel htmlFor="email">Email</FormLabel>
                            <TextField
                                required
                                fullWidth
                                id="email"
                                placeholder="your@email.com"
                                name="email"
                                autoComplete="email"
                                variant="outlined"
                                error={emailError}
                                helperText={emailErrorMessage}
                                color={passwordError ? 'error' : 'primary'}
                            />
                        </FormControl>
                        <FormControl>
                            <FormLabel htmlFor="password">Password</FormLabel>
                            <TextField
                                required
                                fullWidth
                                name="password"
                                placeholder="••••••"
                                type="password"
                                id="password"
                                autoComplete="new-password"
                                variant="outlined"
                                error={passwordError}
                                helperText={passwordErrorMessage}
                                color={passwordError ? 'error' : 'primary'}
                            />
                        </FormControl>

                        <Button sx={{marginTop: "3rem"}}
                                type="submit"
                                fullWidth
                                variant="contained"
                                onClick={validateInputs}
                        >
                            Sign up
                        </Button>
                    </Box>

                    <Box sx={{display: 'flex', flexDirection: 'column', gap: 2}}>

                        <Typography sx={{textAlign: 'center'}}>
                            Already have an account?{' '}
                            <Link to={'/login'}>
                                Sign in
                            </Link>
                        </Typography>
                    </Box>
                </Card>
            </SignInContainer>
        </Box>
    );
}
