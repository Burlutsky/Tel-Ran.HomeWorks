

const Orders = () => {
    return (
        <div>
            Orders
        </div>
    );
};

export default Orders;