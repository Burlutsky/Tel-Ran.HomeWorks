

const Customers = () => {
    return (
        <div>
            Customers
            </div>
    );
};

export default Customers;