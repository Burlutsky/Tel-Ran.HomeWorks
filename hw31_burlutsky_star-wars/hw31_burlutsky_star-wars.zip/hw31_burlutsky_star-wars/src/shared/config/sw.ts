export const baseUrl = 'https://sw-info-api.herokuapp.com/v1/';
