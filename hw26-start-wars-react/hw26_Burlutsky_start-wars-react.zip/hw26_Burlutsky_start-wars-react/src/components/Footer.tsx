

const Footer = () => {
    return (
        <footer>
            <div className="btn">Send me <span>EMAIL</span></div>
        </footer>
    );
};

export default Footer;