const FarGalaxy = () => {
    return (
        <p className="farGalaxy">
            Title: <span>The Empire Strikes Back</span><br/>
            Episode: <span>5</span><br/>
            Release_date: <span>1980-05-17</span><br/>
            <span>It is a dark time for the
			Rebellion. Although the Death Star has been destroyed, Imperial troops have driven the Rebel forces from
			their
			hidden base and pursued them across the galaxy. Evading the dreaded Imperial Starfleet, a group of freedom
			fighters led by Luke Skywalker has established a new secret base on the remote ice world of Hoth. The evil
			lord
			Darth Vader, obsessed with finding young Skywalker, has dispatched thousands of remote probes into the far
			reaches of space....</span>
        </p>
    );
};

export default FarGalaxy;