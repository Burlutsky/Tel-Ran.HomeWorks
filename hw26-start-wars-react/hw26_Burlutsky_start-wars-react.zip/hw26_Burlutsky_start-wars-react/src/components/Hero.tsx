

const Hero = () => {
    return (
        <section className="left">
            <img src="/src/assets/images/main.jpg" alt="Luke"/>
        </section>
    );
};

export default Hero;