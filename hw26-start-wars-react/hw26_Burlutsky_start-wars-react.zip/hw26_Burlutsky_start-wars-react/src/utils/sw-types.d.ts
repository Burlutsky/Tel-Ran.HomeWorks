export type HeroInfo = {
    name: string;
    image: string;
}