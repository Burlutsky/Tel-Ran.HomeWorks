export const navItems: string[] = ['Home', 'About Me', 'Start Wars', 'Contact Me'];
export const config = {
    SWAPI_URL: "https://swapi.info/api/"
}